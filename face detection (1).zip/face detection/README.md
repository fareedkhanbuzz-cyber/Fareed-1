# AOFS — Attendance Optimization Using Face Scan

> **Project for:** T.Y.B.Sc. Data Science (2025–26), Sem V  
> **Author:** Mohammad Fareed Ayub Khan | **Guide:** Asst. Prof. Disha Bhakta  
> **Institution:** Bunts Sangha's S.M. Shetty College, Powai

---

## Overview

AOFS is an automatic classroom attendance system that:
1. **Detects faces** in classroom photos using **MTCNN**
2. **Recognises students** by matching 512-D embeddings via **FaceNet**
3. **Flags proxies** — unknown faces or duplicate claims — using cosine similarity
4. **Visualises trends** in an interactive **Streamlit + Plotly** dashboard

---

## Project Structure

```
face detection/
│
├── core/
│   ├── detector.py        # MTCNN face detection
│   └── embedder.py        # FaceNet embedding generation
│
├── database/
│   ├── schema.sql         # SQLite schema
│   └── db.py              # DB access utilities
│
├── analytics/
│   └── trends.py          # Pandas aggregation & query helpers
│
├── scripts/
│   ├── enroll.py          # Enrol a student from a photo
│   └── process_session.py # Process a classroom image
│
├── images/                # ← Put your classroom photos here
├── student_photos/        # ← Put student reference photos here
│
├── seed_data.py           # Populate DB with synthetic test data
├── app.py                 # Streamlit dashboard
└── requirements.txt
```

---

## Setup

### 1. Create and activate a virtual environment (recommended)

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### 2. Install dependencies

```powershell
pip install -r requirements.txt
```

---

## Usage

### Step 1 — Initialise the database

```powershell
python database/db.py
```

### Step 2 — Enrol students (one per photo)

Place each student's clear portrait photo in the `student_photos/` folder, then run:

```powershell
python scripts/enroll.py student_photos/fareed.jpg S001 "Fareed Khan"
python scripts/enroll.py student_photos/aisha.jpg  S002 "Aisha Sharma"
# ... repeat for each student
```

### Step 3 — Process a classroom lecture photo

Place the classroom image in the `images/` folder, then run:

```powershell
python scripts/process_session.py images/lecture_2025-08-01.jpg DS501 I001
```

The system will:
- Detect all faces in the image
- Match each face against the enrolled student database
- Mark each enrolled student as **Present**, **Absent**, or **Proxy_Flagged**
- Save results to the SQLite database

### Step 4 — Launch the Analytics Dashboard

```powershell
streamlit run app.py
```

Open **http://localhost:8501** in your browser.

---

## Quick Test (No real images needed)

Run the seed script to populate the database with realistic synthetic data instantly:

```powershell
python seed_data.py
streamlit run app.py
```

---

## Dashboard Tabs

| Tab | Description |
|-----|-------------|
| **Weekly Trends** | Bar chart of attendance vs. proxies per week |
| **Heatmap Analytics** | Attendance % by day of week and hour |
| **Verification Distribution** | KDE plot of match distances with threshold line |
| **Student Report** | Per-student attendance timeline, summary stats |

---

## Technology Stack

| Component | Technology |
|-----------|-----------|
| Face Detection | MTCNN |
| Face Recognition | FaceNet (keras-facenet) |
| Data Storage | SQLite |
| Analytics | Pandas |
| Dashboard | Streamlit + Plotly |
| Language | Python 3.9+ |

---

## Proxy Detection Logic

A detected face is considered a **match** if its cosine distance to a student's stored embedding is **< 0.6**.  
If two detections claim the same student, the second is flagged as **Proxy_Flagged**.  
Unrecognised faces (distance ≥ 0.6 for all students) are logged as **Unknown**.
