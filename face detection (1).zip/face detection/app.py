import streamlit as st
import plotly.express as px
import plotly.figure_factory as ff
import pandas as pd
import os
import sys

# Ensure analytics can be imported
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from analytics.trends import (
    get_weekly_attendance_trend,
    get_confidence_distribution,
    get_attendance_heatmap_data,
    get_student_report,
    get_all_student_ids
)
from database.db import init_db

# Initialize DB if not exists
init_db()

# Streamlit config
st.set_page_config(page_title="AOFS Dashboard", layout="wide", page_icon="📊")

st.title("AOFS: Attendance Optimization Using Face Scan")
st.markdown("Automated attendance monitoring and analytics platform.")

# Tabs
tab1, tab2, tab3, tab4 = st.tabs([
    "Weekly Trends", 
    "Heatmap Analytics", 
    "Verification Distribution", 
    "Student Report"
])

# ----------------- Tab 1: Weekly Trends -----------------
with tab1:
    st.header("Weekly Attendance and Proxy Trends")
    st.markdown("Displays the total number of attendances vs. proxies flagged per week.")
    
    try:
        df_weekly = get_weekly_attendance_trend()
        
        if not df_weekly.empty:
            # Melt DataFrame to have a format suitable for barmode='group' in Plotly
            df_melt = df_weekly.melt(id_vars=['week'], 
                                     value_vars=['present_count', 'proxy_count'],
                                     var_name='Status', 
                                     value_name='Count')
            
            # Rename Status values for better readability
            df_melt['Status'] = df_melt['Status'].replace({'present_count': 'Present', 'proxy_count': 'Proxy / Not Exist'})
            
            fig = px.bar(df_melt, x='week', y='Count', color='Status', barmode='group',
                         title="Attendance vs Proxy per Week",
                         color_discrete_map={'Present': '#1f77b4', 'Proxy / Not Exist': '#d62728'},
                         labels={'week': 'Week', 'Count': 'Number of Students'})
            
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No session data available yet. Please process some lectures.")
    except Exception as e:
        st.error(f"Error loading weekly trends: {e}")

# ----------------- Tab 2: Heatmap -----------------
with tab2:
    st.header("Attendance Heatmap by Day and Hour")
    st.markdown("Visualizes when students are most or least likely to attend.")
    
    try:
        df_heat = get_attendance_heatmap_data()
        
        if not df_heat.empty:
            # Create a pivot table for the heatmap
            pivot_df = df_heat.pivot(index='hour_of_day', columns='day_of_week', values='attendance_percent')
            
            # Reorder days
            days_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
            existing_days = [day for day in days_order if day in pivot_df.columns]
            pivot_df = pivot_df[existing_days]
            
            # Plot Heatmap
            fig_heat = px.imshow(pivot_df, 
                                 labels=dict(x="Day of Week", y="Hour of Day", color="Attendance %"),
                                 x=pivot_df.columns,
                                 y=pivot_df.index,
                                 aspect="auto",
                                 color_continuous_scale="RdBu",
                                 title="Average Attendance Percentage Heatmap")
                                 
            fig_heat.update_layout(yaxis=dict(autorange="reversed"))
            st.plotly_chart(fig_heat, use_container_width=True)
        else:
            st.info("No session data available yet.")
    except Exception as e:
        st.error(f"Error loading heatmap: {e}")

# ----------------- Tab 3: KDE Distribution -----------------
with tab3:
    st.header("Verification Confidence Score Distribution")
    st.markdown("Kernel Density Estimate (KDE) plot of the FaceNet 'Distance' scores. (Lower distance = Higher chance of match)")
    
    try:
        df_dist = get_confidence_distribution()
        
        if not df_dist.empty and len(df_dist) > 1:
            # Separate data by category
            valid = df_dist[df_dist['match_type'] == 'Valid Match']['confidence_score'].dropna().tolist()
            mismatch = df_dist[df_dist['match_type'] == 'Mismatch/Proxy/Not_Exist']['confidence_score'].dropna().tolist()
            
            hist_data = []
            group_labels = []
            colors = []
            
            if valid:
                hist_data.append(valid)
                group_labels.append('Valid Match')
                colors.append('#2ca02c') # Green
                
            if mismatch:
                hist_data.append(mismatch)
                group_labels.append('Mismatch/Proxy/Not_Exist')
                colors.append('#d62728') # Red
                
            if hist_data:
                # Create distplot with custom bin_size
                fig_kde = ff.create_distplot(hist_data, group_labels, show_hist=False, colors=colors)
                fig_kde.update_layout(title_text='Distance Distribution by Match Type',
                                      xaxis_title='Cosine Distance (FaceNet)',
                                      yaxis_title='Density')
                
                # Add a vertical line for the threshold (e.g. 0.35)
                fig_kde.add_vline(x=0.35, line_width=2, line_dash="dash", line_color="black", annotation_text="Threshold (0.35)")
                
                st.plotly_chart(fig_kde, use_container_width=True)
            else:
                st.info("Not enough distance data to generate KDE Plot.")
        else:
            st.info("Not enough distance data to generate KDE Plot.")
    except Exception as e:
        st.error(f"Error loading distribution data: {e}")

# ----------------- Tab 4: Student Report -----------------
with tab4:
    st.header("Individual Student Report")
    st.markdown("Check granular attendance data for an enrolled student.")
    
    try:
        students_df = get_all_student_ids()
        if not students_df.empty:
            # Combine ID and Name for the dropdown
            students_df['display'] = students_df['name'] + " (" + students_df['student_id'] + ")"
            selected_display = st.selectbox("Select Student:", students_df['display'].tolist())
            
            # Get selected ID
            selected_id = students_df[students_df['display'] == selected_display]['student_id'].values[0]
            
            report = get_student_report(selected_id)
            stats = report['stats']
            timeline = report['timeline']
            
            st.subheader("Summary")
            col1, col2, col3 = st.columns(3)
            # Handle possible NaN or None
            present = int(stats.get('present_count') or 0)
            absent = int(stats.get('absent_count') or 0)
            proxies = int(stats.get('proxy_count') or 0)
            
            col1.metric("Present", present)
            col2.metric("Absent", absent)
            col3.metric("Proxies Blocked", proxies)
            
            st.subheader("Attendance History")
            if not timeline.empty:
                # Add a color indicator
                def highlight_status(val):
                    color = 'green' if val == 'Present' else 'red' if val in ['Absent', 'Proxy_Flagged'] else 'black'
                    return f'color: {color}'
                    
                st.dataframe(timeline.style.map(highlight_status, subset=['status']), use_container_width=True)
            else:
                st.write("No session records found for this student.")
        else:
            st.info("No enrolled students found in the database.")
    except Exception as e:
        st.error(f"Error loading student report: {e}")
