-- database/schema.sql

CREATE TABLE IF NOT EXISTS students (
    student_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    enrollment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    reference_embedding BLOB NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    session_id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    course_code VARCHAR(50),
    instructor_id VARCHAR(50),
    image_filepath VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS attendance (
    attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER,
    student_id VARCHAR(50), -- can be NULL if it's an Unknown person
    confidence_score FLOAT,
    status VARCHAR(20), -- 'Present', 'Proxy_Flagged', 'Unknown'
    FOREIGN KEY(session_id) REFERENCES sessions(session_id),
    FOREIGN KEY(student_id) REFERENCES students(student_id)
);
