import sqlite3
import numpy as np
import io
import os

DB_PATH = os.path.join(os.path.dirname(__file__), 'attendance.db')
SCHEMA_PATH = os.path.join(os.path.dirname(__file__), 'schema.sql')

# Helper functions to convert numpy arrays to SQLite BLOBs and vice versa
def adapt_array(arr):
    out = io.BytesIO()
    np.save(out, arr)
    out.seek(0)
    return sqlite3.Binary(out.read())

def convert_array(text):
    out = io.BytesIO(text)
    out.seek(0)
    return np.load(out, allow_pickle=True)

# Registers the adapter and converter
sqlite3.register_adapter(np.ndarray, adapt_array)
sqlite3.register_converter("BLOB", convert_array)

def get_connection():
    # detect_types allows automatic conversion of BLOB to numpy arrays
    conn = sqlite3.connect(DB_PATH, detect_types=sqlite3.PARSE_DECLTYPES)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    with open(SCHEMA_PATH, 'r') as f:
        conn.executescript(f.read())
    conn.commit()
    conn.close()

def enroll_student(student_id, name, embedding):
    conn = get_connection()
    c = conn.cursor()
    try:
        c.execute('''
            INSERT INTO students (student_id, name, reference_embedding)
            VALUES (?, ?, ?)
        ''', (student_id, name, embedding))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        print(f"Student {student_id} already exists.")
        return False
    finally:
        conn.close()

def get_all_students():
    """
    Returns a list of dictionaries: [{'student_id': id, 'name': n, 'embedding': arr}, ...]
    """
    conn = get_connection()
    c = conn.cursor()
    c.execute('SELECT student_id, name, reference_embedding FROM students')
    rows = c.fetchall()
    conn.close()
    
    students = []
    for r in rows:
        students.append({
            'student_id': r['student_id'],
            'name': r['name'],
            'embedding': r['reference_embedding']
        })
    return students

def log_session(course_code, instructor_id, image_filepath):
    conn = get_connection()
    c = conn.cursor()
    c.execute('''
        INSERT INTO sessions (course_code, instructor_id, image_filepath)
        VALUES (?, ?, ?)
    ''', (course_code, instructor_id, image_filepath))
    session_id = c.lastrowid
    conn.commit()
    conn.close()
    return session_id

def record_attendance(session_id, records):
    """
    records: list of tuples (student_id, confidence_score, status)
    status can be 'Present', 'Proxy_Flagged', 'Unknown'
    student_id can be None for 'Unknown'
    """
    conn = get_connection()
    c = conn.cursor()
    c.executemany('''
        INSERT INTO attendance (session_id, student_id, confidence_score, status)
        VALUES (?, ?, ?, ?)
    ''', [(session_id, r[0], r[1], r[2]) for r in records])
    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_db()
    print("Database initialized successfully at", DB_PATH)
