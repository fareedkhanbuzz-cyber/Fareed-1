"""
seed_data.py — Populate the database with synthetic attendance records
for testing the analytics dashboard without needing real classroom images.

Run with:
    python seed_data.py
"""

import sys
import os
import random
import sqlite3
import numpy as np
from datetime import datetime, timedelta
import io

# Add parent dir to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

DB_PATH = os.path.join('database', 'attendance.db')

STUDENT_NAMES = [
    ("S001", "Fareed Khan"),
    ("S002", "Aisha Sharma"),
    ("S003", "Rohan Mehta"),
    ("S004", "Priya Nair"),
    ("S005", "Arjun Patel"),
    ("S006", "Zara Khan"),
    ("S007", "Vikram Joshi"),
    ("S008", "Sneha Pillai"),
    ("S009", "Ravi Gupta"),
    ("S010", "Meena Iyer"),
]

COURSE_CODES = ["DS501", "DS502", "DS503"]
INSTRUCTOR_ID = "I001"


def adapt_array(arr):
    out = io.BytesIO()
    np.save(out, arr)
    out.seek(0)
    return sqlite3.Binary(out.read())


def get_connection():
    return sqlite3.connect(DB_PATH)


def seed():
    conn = get_connection()
    c = conn.cursor()

    # Initialize schema
    with open(os.path.join('database', 'schema.sql')) as f:
        conn.executescript(f.read())
    conn.commit()

    print("Seeding students...")
    for student_id, name in STUDENT_NAMES:
        # Generate a random 512-dim reference embedding
        embedding = np.random.rand(512).astype(np.float32)
        blob = adapt_array(embedding)
        try:
            c.execute(
                'INSERT OR IGNORE INTO students (student_id, name, reference_embedding) VALUES (?, ?, ?)',
                (student_id, name, blob)
            )
        except Exception as e:
            print(f"  Skipped {name}: {e}")

    conn.commit()
    print(f"Seeded {len(STUDENT_NAMES)} students.")

    print("Seeding sessions and attendance records...")
    base_date = datetime(2025, 8, 1, 9, 0, 0)
    DAYS_IN_SEMESTER = 100
    sessions_created = 0

    for day_offset in range(0, DAYS_IN_SEMESTER, 5):
        session_date = base_date + timedelta(days=day_offset)
        # Skip Sundays
        if session_date.weekday() == 6:
            continue

        course_code = random.choice(COURSE_CODES)
        image_fp = f"images/session_{session_date.strftime('%Y%m%d_%H%M')}.jpg"
        ts = session_date.strftime('%Y-%m-%d %H:%M:%S')

        c.execute(
            'INSERT INTO sessions (timestamp, course_code, instructor_id, image_filepath) VALUES (?, ?, ?, ?)',
            (ts, course_code, INSTRUCTOR_ID, image_fp)
        )
        session_id = c.lastrowid
        sessions_created += 1

        # Simulate attendance
        records = []
        for student_id, name in STUDENT_NAMES:
            # Friday afternoons → lower attendance
            is_friday = session_date.weekday() == 4
            prob_present = 0.60 if is_friday else 0.82

            roll = random.random()
            if roll < prob_present:
                status = 'Present'
                score = round(random.uniform(0.05, 0.35), 4)  # low distance = good match
            elif roll < prob_present + 0.10:
                status = 'Proxy_Flagged'
                score = round(random.uniform(0.55, 0.75), 4)
            else:
                status = 'Absent'
                score = None

            records.append((session_id, student_id, score, status))

        # Add 1-2 unknown faces per session
        for _ in range(random.randint(0, 2)):
            score = round(random.uniform(0.7, 0.95), 4)
            records.append((session_id, None, score, 'Unknown'))

        c.executemany(
            'INSERT INTO attendance (session_id, student_id, confidence_score, status) VALUES (?, ?, ?, ?)',
            records
        )

    conn.commit()
    conn.close()
    print(f"Seeded {sessions_created} sessions with attendance records.")
    print("Done! Run `streamlit run app.py` to view the dashboard.")


if __name__ == "__main__":
    seed()
