import pandas as pd
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'database', 'attendance.db')

def get_connection():
    return sqlite3.connect(DB_PATH)

def get_weekly_attendance_trend():
    """
    Returns a DataFrame with weekly attendance and proxy counts.
    """
    query = '''
    SELECT 
        strftime('%Y-%W', s.timestamp) AS week,
        SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present_count,
        SUM(CASE WHEN a.status IN ('Proxy_Flagged', 'Unknown', 'Not_Exist') THEN 1 ELSE 0 END) AS proxy_count
    FROM sessions s
    JOIN attendance a ON s.session_id = a.session_id
    GROUP BY week
    ORDER BY week
    '''
    with get_connection() as conn:
        df = pd.read_sql_query(query, conn)
    return df

def get_confidence_distribution():
    """
    Returns a DataFrame of confidence scores and whether they are valid matches or proxies/unknowns.
    """
    query = '''
    SELECT 
        confidence_score,
        CASE WHEN status = 'Present' THEN 'Valid Match'
             ELSE 'Mismatch/Proxy/Not_Exist' END as match_type
    FROM attendance
    WHERE confidence_score IS NOT NULL
    '''
    with get_connection() as conn:
        df = pd.read_sql_query(query, conn)
    return df

def get_attendance_heatmap_data():
    """
    Returns data for attendance heatmap (Day of Week vs Hour of Day).
    """
    query = '''
    SELECT 
        CASE cast(strftime('%w', s.timestamp) as integer)
            WHEN 0 THEN 'Sunday'
            WHEN 1 THEN 'Monday'
            WHEN 2 THEN 'Tuesday'
            WHEN 3 THEN 'Wednesday'
            WHEN 4 THEN 'Thursday'
            WHEN 5 THEN 'Friday'
            WHEN 6 THEN 'Saturday'
        END as day_of_week,
        cast(strftime('%H', s.timestamp) as integer) as hour_of_day,
        COUNT(a.attendance_id) as total_scans,
        SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) as present_count
    FROM sessions s
    JOIN attendance a ON s.session_id = a.session_id
    GROUP BY day_of_week, hour_of_day
    '''
    with get_connection() as conn:
        df = pd.read_sql_query(query, conn)
        
    if not df.empty:
        # Calculate percentage
        df['attendance_percent'] = (df['present_count'] / df['total_scans']) * 100
    
    return df

def get_student_report(student_id):
    """
    Returns a dictionary with stats and a DataFrame of timeline for a specific student.
    """
    # Timeline
    timeline_query = '''
    SELECT 
        s.timestamp, s.course_code, a.status
    FROM sessions s
    JOIN attendance a ON s.session_id = a.session_id
    WHERE a.student_id = ?
    ORDER BY s.timestamp
    '''
    with get_connection() as conn:
        timeline_df = pd.read_sql_query(timeline_query, conn, params=(student_id,))
        
    # Aggregate Stats
    stats_query = '''
    SELECT 
        SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) as present_count,
        SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) as absent_count,
        SUM(CASE WHEN status = 'Proxy_Flagged' THEN 1 ELSE 0 END) as proxy_count
    FROM attendance
    WHERE student_id = ?
    '''
    with get_connection() as conn:
        stats_df = pd.read_sql_query(stats_query, conn, params=(student_id,))
        
    stats = {}
    if not stats_df.empty:
        # Return first row as dict
        stats = stats_df.iloc[0].to_dict()
        
    return {'timeline': timeline_df, 'stats': stats}

def get_all_student_ids():
    with get_connection() as conn:
        df = pd.read_sql_query('SELECT student_id, name FROM students', conn)
    return df
