import numpy as np
from keras_facenet import FaceNet

# Initialize FaceNet globally
embedder = FaceNet()

def get_embedding(face_pixels):
    """
    Given a cropped face image (as a numpy array, RGB format, usually 160x160),
    returns a 512-dimensional embedding vector.
    """
    # FaceNet model expects a batch of images
    face_pixels = np.expand_dims(face_pixels, axis=0)
    
    # Generate embedding
    embedding = embedder.embeddings(face_pixels)
    
    # Return 1D array
    return embedding[0]

def get_embeddings(faces_list):
    """
    Given a list of cropped faces (160x160 RGB), return their embeddings.
    """
    if len(faces_list) == 0:
        return []
        
    faces_array = np.array(faces_list)
    embeddings = embedder.embeddings(faces_array)
    return embeddings
