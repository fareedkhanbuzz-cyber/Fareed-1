from mtcnn import MTCNN
import cv2
import numpy as np

# Initialize MTCNN globally to avoid reloading the model on every call
detector = MTCNN()

def detect_faces(image_path, min_confidence=0.9):
    """
    Detects faces in an image and returns a list of cropped face images and their bounding boxes.
    Returns:
        faces: list of numpy arrays (160x160 RGB images)
        boxes: list of tuples (x1, y1, x2, y2)
    """
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"Could not load image at {image_path}")
        
    # MTCNN expects RGB
    image = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
    try:
        results = detector.detect_faces(image)
    except ValueError as e:
        # MTCNN can sometimes throw ValueError regarding empty output shape (e.g. 0,48,48,3)
        # if the image has no features or is too small/complex. We treat as no faces found.
        print(f"MTCNN warning: {e}")
        return [], []
    except Exception as e:
        print(f"MTCNN unexpected error: {e}")
        return [], []
    
    faces = []
    boxes = []
    
    for result in results:
        if result['confidence'] >= min_confidence:
            x, y, width, height = result['box']
            # Handle potential negative coordinates returned by MTCNN
            x1, y1 = max(0, x), max(0, y)
            x2, y2 = x1 + width, y1 + height
            
            # Extract the face ROI
            face = image[y1:y2, x1:x2]
            
            # If the face is invalid (e.g. edge of the image)
            if face.size == 0:
                continue
                
            # Resize to the standard size for FaceNet (160x160)
            face_resized = cv2.resize(face, (160, 160))
            
            faces.append(face_resized)
            boxes.append((x1, y1, x2, y2))
            
    return faces, boxes
