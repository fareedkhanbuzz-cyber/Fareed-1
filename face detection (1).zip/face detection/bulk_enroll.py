"""
bulk_enroll.py — Enroll all students from the img/ folder.
Maps person 1..6 to student IDs S001..S006 with placeholder names.
Run:  python bulk_enroll.py
"""
import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.detector import detect_faces
from core.embedder import get_embedding
from database.db import enroll_student, init_db

# Map image filename -> (student_id, name)
STUDENTS = {
    "person 1.jpeg": ("S001", "Person 1"),
    "person 2.jpeg": ("S002", "Person 2"),
    "person 3.jpeg": ("S003", "Person 3"),
    "person 4.jpeg": ("S004", "Person 4"),
    "person 5.jpeg": ("S005", "Person 5"),
    "person 6.jpeg": ("S006", "Person 6"),
}

IMG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "img")

def main():
    init_db()
    print("Starting bulk enrollment...\n")
    
    for filename, (student_id, name) in STUDENTS.items():
        image_path = os.path.join(IMG_DIR, filename)
        
        if not os.path.exists(image_path):
            print(f"  [SKIP] Image not found: {image_path}")
            continue
            
        print(f"  Processing {filename} → {name} ({student_id}) ...", end=" ", flush=True)
        
        try:
            faces, _ = detect_faces(image_path)
        except Exception as e:
            print(f"ERROR reading image: {e}")
            continue
            
        if len(faces) == 0:
            print("ERROR: No face detected!")
            continue
        
        # Use the first (most prominent) face
        face = faces[0]
        embedding = get_embedding(face)
        
        success = enroll_student(student_id, name, embedding)
        if success:
            print("Enrolled ✅")
        else:
            print("Already exists, skipped.")
    
    print("\nBulk enrollment complete!")
    print("You can now run:  streamlit run app.py")
    print("Or process a classroom image with:  python scripts/process_session.py <image> DS501 I001")

if __name__ == "__main__":
    main()
