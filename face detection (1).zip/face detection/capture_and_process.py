"""
capture_and_process.py 
Captures an image from the webcam, saves it to the img/ folder,
and processes it for attendance right away. 
Press SPACE to take the photo, or ESC to cancel.
"""
import sys
import os
import cv2

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from scripts.process_session import process_image
from database.db import init_db

def main():
    init_db()
    
    cap = cv2.VideoCapture(0)
    print("Opening webcam... Press SPACE to take an attendance photo, or ESC to cancel.")
    
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return
        
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame.")
            break
            
        cv2.imshow("Webcam - Press SPACE to capture, ESC to exit", frame)
        
        k = cv2.waitKey(1)
        if k % 256 == 27:
            # ESC pressed
            print("Escape hit, closing.")
            break
        elif k % 256 == 32:
            # SPACE pressed
            img_path = os.path.join("img", "live_capture.jpg")
            cv2.imwrite(img_path, frame)
            print(f"\nImage captured and saved to {img_path}")
            
            # Process the image!
            print("Processing attendance...")
            process_image(img_path, "DS501", "I001")
            break
            
    cap.release()
    cv2.destroyAllWindows()
    
if __name__ == "__main__":
    main()
