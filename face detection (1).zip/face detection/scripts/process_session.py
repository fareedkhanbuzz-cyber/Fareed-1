import argparse
import sys
import os
from scipy.spatial.distance import cosine

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.detector import detect_faces
from core.embedder import get_embeddings
from database.db import get_all_students, log_session, record_attendance, init_db

# Threshold for FaceNet Cosine Distance
# Lowered to 0.35 since pairwise distances between different enrolled students can be as low as 0.44.
MATCH_THRESHOLD = 0.35 

def process_image(image_path, course_code, instructor_id):
    print(f"Processing session image: {image_path}")
    
    try:
        faces, boxes = detect_faces(image_path)
    except Exception as e:
        print(f"Error reading image: {e}")
        return False
        
    print(f"Detected {len(faces)} faces.")
    if len(faces) == 0:
        print("No faces to process.")
        return True
        
    embeddings = get_embeddings(faces)
    students = get_all_students()
    
    print(f"Loaded {len(students)} enrolled students from database.")
    
    # Start session log
    session_id = log_session(course_code, instructor_id, image_path)
    attendance_records = []
    
    # Track identified students to detect multiple claims on same student (proxies)
    present_students = set()
    
    for i, emb in enumerate(embeddings):
        best_score = float('inf')
        best_match = None
        
        for student in students:
            # SciPy cosine distance. Distance < 0.6 usually indicates a match for FaceNet.
            dist = cosine(emb, student['embedding'])
            if dist < best_score:
                best_score = dist
                best_match = student
                
        # Handle matches
        if best_match is not None and best_score < MATCH_THRESHOLD:
            # Check for multiple claims
            if best_match['student_id'] in present_students:
                print(f"Face {i}: Matched {best_match['name']} but they are already marked present. Flagging as Proxy.")
                attendance_records.append((best_match['student_id'], best_score, 'Proxy_Flagged'))
            else:
                print(f"Face {i}: Matched {best_match['name']} (Score: {best_score:.3f})")
                attendance_records.append((best_match['student_id'], best_score, 'Present'))
                present_students.add(best_match['student_id'])
        else:
            print(f"Face {i}: Person does not exist in database (Best score: {best_score:.3f})")
            # Note: We assign None to student_id since it's an unknown person
            attendance_records.append((None, best_score, 'Not_Exist'))
            
    # Mark enrolled students not found as Absent
    for student in students:
        if student['student_id'] not in present_students:
            attendance_records.append((student['student_id'], None, 'Absent'))
            
    print("Recording attendance...")
    record_attendance(session_id, attendance_records)
    print("Session processing complete.")
    return True

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process a classroom image for attendance.")
    parser.add_argument("image_path", help="Path to the classroom photo")
    parser.add_argument("course_code", help="Course code (e.g. CS101)")
    parser.add_argument("instructor_id", help="Instructor ID")
    
    args = parser.parse_args()
    
    # Ensure DB is initialized
    init_db()
    
    process_image(args.image_path, args.course_code, args.instructor_id)
