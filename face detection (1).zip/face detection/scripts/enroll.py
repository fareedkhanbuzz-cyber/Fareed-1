import argparse
import sys
import os

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.detector import detect_faces
from core.embedder import get_embedding
from database.db import enroll_student, init_db

def enroll(image_path, student_id, name):
    print(f"Enrolling {name} ({student_id}) from {image_path}...")
    
    try:
        faces, boxes = detect_faces(image_path)
    except Exception as e:
        print(f"Error reading image: {e}")
        return False
        
    if len(faces) == 0:
        print("Error: No faces detected in the image.")
        return False
    elif len(faces) > 1:
        print("Error: Multiple faces detected. Please use a clear portrait image with only one face.")
        return False
        
    face = faces[0]
    embedding = get_embedding(face)
    
    success = enroll_student(student_id, name, embedding)
    if success:
        print("Successfully enrolled student!")
    return success

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Enroll a student with a reference image.")
    parser.add_argument("image_path", help="Path to the student's photo")
    parser.add_argument("student_id", help="Unique student ID")
    parser.add_argument("name", help="Full name of the student")
    
    args = parser.parse_args()
    
    # Ensure DB is initialized
    init_db()
    
    enroll(args.image_path, args.student_id, args.name)
