import sys
import os
from scipy.spatial.distance import cosine

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from database.db import get_all_students

def test_distances():
    students = get_all_students()
    
    print(f"Loaded {len(students)} students.")
    if len(students) < 2:
        print("Need at least 2 students to compare.")
        return
        
    print("\nPairwise Cosine Distances:")
    print("-" * 40)
    for i in range(len(students)):
        for j in range(i + 1, len(students)):
            s1 = students[i]
            s2 = students[j]
            dist = cosine(s1['embedding'], s2['embedding'])
            print(f"{s1['name']} vs {s2['name']}: {dist:.4f}")

if __name__ == "__main__":
    test_distances()
